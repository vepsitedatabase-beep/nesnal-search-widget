package com.nesnal.searchwidget

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class SearchActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(3)
    private val handler = Handler(Looper.getMainLooper())
    private var pendingSearch: Runnable? = null
    private lateinit var results: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 12)
            setBackgroundColor(0xFFF5F7F9.toInt())
        }
        val title = TextView(this).apply {
            text = "NESNAL"
            textSize = 23f
            setTextColor(0xFF153D52.toInt())
            setPadding(4, 4, 4, 18)
        }
        input = EditText(this).apply {
            hint = "Search products..."
            singleLine = true
            textSize = 17f
            setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0)
            setPadding(16, 12, 16, 12)
            background = getDrawable(R.drawable.search_bar_bg)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title)
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        root.addView(results, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                pendingSearch?.let(handler::removeCallbacks)
                val query = s?.toString()?.trim().orEmpty()
                pendingSearch = Runnable {
                    if (query.length >= 2) searchProducts(query)
                    else showMessage("Type at least 2 letters to search")
                }
                handler.postDelayed(pendingSearch!!, 350)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        input.requestFocus()
    }

    private fun searchProducts(query: String) {
        runOnUiThread { showMessage("Searching Nesnal products…") }
        executor.execute {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = URL("https://nesnal.com/wp-json/wc/store/v1/products?search=$encoded&per_page=10")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("Accept", "application/json")
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val array = JSONArray(body)
                runOnUiThread {
                    results.removeAllViews()
                    if (array.length() == 0) showMessage("No products found")
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        addProduct(
                            item.optString("name"),
                            item.optString("permalink"),
                            item.optJSONArray("images")?.optJSONObject(0)?.optString("src").orEmpty(),
                            item.optJSONObject("prices")?.optString("price").orEmpty(),
                            item.optJSONObject("prices")?.optString("currency_symbol").orEmpty()
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { showMessage("Could not load products. Check internet and try again.") }
            }
        }
    }

    private fun addProduct(name: String, link: String, imageUrl: String, rawPrice: String, currency: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 12, 10, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        row.addView(image, LinearLayout.LayoutParams(64, 64))
        val textBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 0, 0, 0)
        }
        val nameView = TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(0xFF202124.toInt())
        }
        val priceView = TextView(this).apply {
            text = formatPrice(rawPrice, currency)
            textSize = 14f
            setTextColor(0xFF2878D0.toInt())
        }
        textBox.addView(nameView)
        textBox.addView(priceView)
        row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
        row.setOnClickListener {
            if (link.startsWith("https://nesnal.com/")) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
            }
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = 1
        results.addView(row, params)
        if (imageUrl.startsWith("https://")) {
            executor.execute {
                try {
                    val bitmap = URL(imageUrl).openStream().use { BitmapFactory.decodeStream(it) }
                    runOnUiThread { image.setImageBitmap(bitmap) }
                } catch (_: Exception) {}
            }
        }
    }

    private fun formatPrice(raw: String, currency: String): String {
        return try {
            val amount = raw.toLong() / 100.0
            "Price: $currency${"%.2f".format(amount)}"
        } catch (_: Exception) { "" }
    }

    private fun showMessage(message: String) {
        results.removeAllViews()
        results.addView(TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(0xFF666666.toInt())
            setPadding(8, 20, 8, 20)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }
}
