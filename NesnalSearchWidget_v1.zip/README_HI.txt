NESNAL SEARCH WIDGET - STARTER ANDROID PROJECT

Is project mein:
- Android home screen par full-width rounded search widget hai.
- Widget par tap karne se search screen khulti hai.
- Search screen WooCommerce Store API se Nesnal products dhoondhti hai.
- Product name, image, price dikhte hain.
- Product tap karne par nesnal.com ka product page khulta hai.

IMPORTANT:
Yeh Android Studio source project hai, ready-made APK nahi. Is environment mein Android SDK/Gradle build run nahi kiya gaya, isliye APK build aur real-device testing abhi baaki hai.

BUILD:
1. Windows par Android Studio install karein.
2. Android Studio > Open > is folder ko select karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. App install karein.
6. Home screen long-press > Widgets > Nesnal Search > Add.

API endpoint:
https://nesnal.com/wp-json/wc/store/v1/products?search=hammer&per_page=10

NOTE:
Android launcher widget itself is a tappable search bar. Text entry and live suggestions happen in the app's search screen after tapping, because standard Android home-screen widgets do not provide a normal editable text field across launchers.
